import os
import time
import json
from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'supersecretkey'
UPLOAD_FOLDER = os.path.join(app.root_path, 'static', 'uploaded')


os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Fix: Get absolute path for users.json relative to this script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USERS_FILE = os.path.join(BASE_DIR, 'users.json')

with open(USERS_FILE) as f:
    USERS = json.load(f)

def save_users():
    with open(USERS_FILE, 'w') as f:
        json.dump(USERS, f)

@app.route('/')
def welcome():
    return render_template('welcome.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # FORCE ACCEPT if username and password both are "admin"
        if username == 'admin' and password == 'admin':
            session['user'] = username
            return redirect('/gallery')
        
        # Else reject login
        error = "❌ Invalid username or password"
    
    return render_template('login.html', error=error)


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        u, p = request.form['username'], request.form['password']
        if u in USERS:
            return "❌ User already exists"
        USERS[u] = generate_password_hash(p)
        save_users()
        return redirect('/login')
    return render_template('signup.html')

@app.route('/forgot_password')
def forgot_password():
    return render_template('forgot_password.html')

@app.route('/gallery', methods=['GET', 'POST'])
def gallery():
    if 'user' not in session:
        return redirect('/login')

    if request.method == 'POST' and 'image' in request.files:
        file = request.files['image']
        if file.filename != '':
            filename = f"{int(time.time())}_{file.filename}"
            file.save(os.path.join(UPLOAD_FOLDER, filename))
    images = sorted(os.listdir(UPLOAD_FOLDER), reverse=True)
    return render_template('gallery.html', images=images)

@app.route('/delete/<filename>', methods=['POST'])
def delete_image(filename):
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    print(f"Trying to delete: {filepath}")
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
            print("✅ File deleted")
        else:
            print("❌ File not found")
    except Exception as e:
        print(f"🚨 Error while deleting: {e}")
    return redirect('/gallery')


@app.route('/download/<filename>')
def download(filename):
    return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
